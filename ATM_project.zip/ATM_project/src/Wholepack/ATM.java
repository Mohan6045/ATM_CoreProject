package Wholepack;

public class ATM extends optionMenu
{
	
	public static void main(String[] args)
	{
		optionMenu opm=new optionMenu();
		opm.getLogin();
		
	}
}
