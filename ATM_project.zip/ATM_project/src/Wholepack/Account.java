package Wholepack;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Account {

     Scanner input =new Scanner(System.in);
	
	DecimalFormat moneyformat=new DecimalFormat("'$'###,##0.00");
	
	
	private int customerNumber;
	private  int PinNumber;
	private double checkingBalance=0;
	private double savingBalance=0;
	
	public int getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(int customerNumber) {
		this.customerNumber = customerNumber;
	}
	public int getPinNumber() {
		return PinNumber;
	}
	public void setPinNumber(int pinNumber) {
		PinNumber = pinNumber;
	}
	public double getCheckingBalance() {
		return checkingBalance;
	}
	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}
	public double getSavingBalance() {
		return savingBalance;
	}
	public void setSavingBalance(double savingBalance) {
		this.savingBalance = savingBalance;
	}
//---------------------------------------------------------------------------------------------------------------------	
	public void getCheckingWithdrawInput()
	{
		System.out.println("Checking Acount Balance:" + moneyformat.format(checkingBalance));
		System.out.println("Amount you wanna Withdraw from checking Account:");
		double amount=input.nextDouble();
		if((checkingBalance-amount)>=0)
		{
			calCheckingWthdraw(amount);
			System.out.println("New Checking Account Balance: " + moneyformat.format(checkingBalance));
		}
		else 
		{
			System.out.println("Entered amount is not available in your account");
		}
		
	}
	private double calCheckingWthdraw(double amount) {
		checkingBalance =checkingBalance-amount;
		return checkingBalance;
		
	}
//--------------------------------------------------------------------------------------------------------------------
	
	public void getSavingWithdrawInput()
	{
		System.out.println("Saving Acount Balance:" + moneyformat.format(savingBalance));
		System.out.println("Amount you wanna Withdraw from saving Account:");
		double amount=input.nextDouble();
		if((savingBalance-amount)>=0)
		{
			calSavingWthdraw(amount);
			System.out.println("New saving Account Balance: " + moneyformat.format(savingBalance));
		}
		else 
		{
			System.out.println("Entered amount is not available in your account");
		}
		
	}
	private double calSavingWthdraw(double amount) {
		savingBalance =savingBalance-amount;
		return savingBalance;
		
	}
//----------------------------------------------------------------------------------------------------------------------	
	public void getSavingDepositInput()
	{
		System.out.println("Saving Acount Balance:" + moneyformat.format(savingBalance));
		System.out.println("Amount you wanna Deposit from saving Account:");
		double amount=input.nextDouble();
		if((savingBalance+amount)>=0)
		{
			calSavingDeposit(amount);
			System.out.println("New saving Account Balance: " + moneyformat.format(savingBalance));
		}
		else 
		{
			System.out.println("Entered amount is not available in your account");
		}
		
	}
	private double calSavingDeposit(double amount) {
		savingBalance =savingBalance+amount;
		return savingBalance;
		
	}
	
//---------------------------------------------------------------------------------------------------------------------
	
	public void getCheckingDepositInput()
	{
		System.out.println("Checking Acount Balance:" + moneyformat.format(checkingBalance));
		System.out.println("Amount you wanna Deposit from checking Account:");
		double amount=input.nextDouble();
		if((checkingBalance+amount)>=0)
		{
			calCheckingdeposit(amount);
			System.out.println("New Checking Account Balance: " + moneyformat.format(checkingBalance));
		}
		else 
		{
			System.out.println("Entered amount is not available in your account");
		}
		
	}
	private double calCheckingdeposit(double amount) {
		checkingBalance =checkingBalance+amount;
		return checkingBalance;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
